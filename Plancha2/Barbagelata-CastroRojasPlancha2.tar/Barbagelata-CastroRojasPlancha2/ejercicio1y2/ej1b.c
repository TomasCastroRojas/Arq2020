int main () {
  return 0xFE - 1;
}